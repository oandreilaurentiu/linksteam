# Steamlinker
Steamlinker, adds a feature in to teamspeak 3 where you can click a steam link and it would open in your steam client instead of your default browser. 

# Features
More features will be coming to allow you to have a smoother experience with steam and teamspeak 3 combined.

1. Links (✓)
2. Update notification (✓)


#Suggestions
If you have a suggestion which could improve Steamlinker then open an [new issue ticket](https://github.com/Galtrox/Steamlinker/issues)


# Install Steps

1. download steamlinker

2. In teamspeak 3 go to Tools --> Options (Alt+p) --> Addons --> Browse online --> Search for "python" ---> pyTSon Plugin --> install 

3. drag steamlinker in to your AppData\Roaming\TS3Client\plugins\pyTSon\scripts folder.

4. In teamspeak 3 go to Plugins(should be at the top of the teamspeak 3 client) --> pyTSon --> Settings --> Press "Reload all" --> Tick Steamlinker if it's not ticked --> your done :D

# Injoy!
Hope you injoy the plugin and dont forget to tell people about this plugin, they wold be thankful :D
